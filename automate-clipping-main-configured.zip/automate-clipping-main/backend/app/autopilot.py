"""Opt-in 24/7 source discovery for authorized/Creative Commons YouTube videos.

The scheduler intentionally uses the official YouTube Data API and searches only
videos marked Creative Commons. It creates at most one source job per 4-hour UTC
slot (six per day), limits each source to one published short, records attribution,
and persists seen IDs to avoid repeat processing.

Required configuration:
  EDGETAPE_AUTOPILOT_ENABLED=1
  EDGETAPE_YOUTUBE_API_KEY=...
  EDGETAPE_AUTOPILOT_OWNER_ID=<existing Edgetape user ID>

Connected destination accounts are discovered automatically for the configured user.

Do not use this feature for material you do not have permission to reuse. API
availability and each platform's upload permissions/rate limits still apply.
"""
from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

import httpx

from .models import Job
from .storage import JobStore
from .tasks import enqueue_job

logger = logging.getLogger("edgetape.autopilot")
API_BASE = "https://www.googleapis.com/youtube/v3"
POLL_SECONDS = 300
SLOT_HOURS = (0, 4, 8, 12, 16, 20)
SEARCH_TERMS = (
    "educational science explained", "history documentary", "technology explained",
    "personal development talk", "nature wildlife education", "space astronomy",
    "business education", "healthy cooking tutorial", "language learning lesson",
    "public domain history lecture", "creative commons educational talk",
    "inspiring interview", "book discussion", "engineering explained",
    "travel culture documentary", "music education lesson",
)


def _storage_root() -> Path:
    return Path(os.environ.get("EDGETAPE_STORAGE", "./storage")).expanduser().resolve()


def _state_path(root: Path) -> Path:
    return root / ".autopilot_state.json"


def _read_state(path: Path) -> dict:
    try:
        state = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(state, dict):
            return state
    except (OSError, ValueError):
        pass
    return {"date": "", "last_slot": -1, "seen_ids": []}


def _write_state(path: Path, state: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _api_key() -> str:
    return os.environ.get("EDGETAPE_YOUTUBE_API_KEY", "").strip()


def _search_candidates(client: httpx.Client, api_key: str, term: str, seen: set[str]) -> list[dict]:
    """Search recent CC-licensed videos, then verify the license via videos.list."""
    response = client.get(f"{API_BASE}/search", params={
        "part": "snippet", "type": "video", "videoLicense": "creativeCommon",
        "order": "date", "maxResults": 25, "q": term,
        "relevanceLanguage": "en", "regionCode": "US", "key": api_key,
    })
    response.raise_for_status()
    items = response.json().get("items", [])
    ids = [str((item.get("id") or {}).get("videoId") or "") for item in items]
    ids = [video_id for video_id in ids if video_id and video_id not in seen]
    if not ids:
        return []
    details = client.get(f"{API_BASE}/videos", params={
        "part": "snippet,status,contentDetails", "id": ",".join(ids), "key": api_key,
    })
    details.raise_for_status()
    candidates = []
    for item in details.json().get("items", []):
        status = item.get("status") or {}
        snippet = item.get("snippet") or {}
        # Defense in depth: never process a video unless API confirms CC license.
        if status.get("license") != "creativeCommon":
            continue
        if status.get("privacyStatus") != "public" or status.get("embeddable") is False:
            continue
        video_id = str(item.get("id") or "")
        if not video_id or video_id in seen:
            continue
        candidates.append({
            "id": video_id,
            "url": f"https://www.youtube.com/watch?v={quote(video_id)}",
            "title": str(snippet.get("title") or "Untitled video"),
            "channel": str(snippet.get("channelTitle") or "Unknown channel"),
            "channel_id": str(snippet.get("channelId") or ""),
            "published_at": str(snippet.get("publishedAt") or ""),
            "license": "Creative Commons Attribution",
        })
    return candidates


def discover_candidate(client: httpx.Client, api_key: str, seen: set[str]) -> dict | None:
    # One search.list call per tick protects the YouTube API quota (search.list is costly).
    # Rotate terms every 30 minutes so a quiet niche does not block discovery all day.
    offset = int(time.time() // 1800) % len(SEARCH_TERMS)
    term = SEARCH_TERMS[offset]
    try:
        candidates = _search_candidates(client, api_key, term, seen)
        return candidates[0] if candidates else None
    except Exception as exc:  # API quota/network issues must not kill the service
        logger.warning("YouTube discovery failed for term %r: %s", term, exc)
        return None


def run_once() -> bool:
    """Run one scheduler tick. Returns True if a source job was queued."""
    if os.environ.get("EDGETAPE_AUTOPILOT_ENABLED", "0").strip() != "1":
        return False
    api_key = _api_key()
    owner_id = os.environ.get("EDGETAPE_AUTOPILOT_OWNER_ID", "").strip()
    if not api_key or not owner_id:
        logger.warning("Autopilot enabled but YouTube API key or owner ID is missing")
        return False

    # Discover only destination accounts explicitly connected by this user.
    # Never guess credentials or bypass OAuth/platform permissions.
    try:
        from sqlalchemy import select
        from .db import SessionLocal
        from .users import LinkedAccount
        account_map = {
            "youtube_shorts": "youtube", "tiktok": "tiktok",
            "facebook_reels": "facebook", "instagram_reels": "instagram",
        }
        requested = [x.strip() for x in os.environ.get(
            "EDGETAPE_AUTOPILOT_PLATFORMS",
            "youtube_shorts,tiktok,facebook_reels,instagram_reels",
        ).split(",") if x.strip()]
        db = SessionLocal()
        try:
            rows = db.scalars(select(LinkedAccount).where(
                LinkedAccount.user_id == owner_id,
                LinkedAccount.platform.in_(list(set(account_map.values()))),
            )).all()
            targets = []
            for platform in requested:
                account_platform = account_map.get(platform)
                row = next((r for r in rows if r.platform == account_platform), None)
                if row is not None:
                    targets.append({"platform": platform, "account": row.name})
            if not targets:
                logger.warning("No connected autopilot destination accounts found for owner %r", owner_id)
                return False
        finally:
            db.close()
    except Exception as exc:
        logger.warning("Could not verify autopilot destination accounts: %s", exc)
        return False

    now = datetime.now(timezone.utc)
    slot = max((i for i, hour in enumerate(SLOT_HOURS) if now.hour >= hour), default=-1)
    root = _storage_root()
    root.mkdir(parents=True, exist_ok=True)
    state_file = _state_path(root)
    state = _read_state(state_file)
    today = now.date().isoformat()
    if state.get("date") != today:
        state = {"date": today, "last_slot": -1, "seen_ids": state.get("seen_ids", [])[-5000:]}
    if slot < 0 or slot <= int(state.get("last_slot", -1)):
        return False

    seen = set(str(x) for x in state.get("seen_ids", []))
    with httpx.Client(timeout=15, follow_redirects=True) as client:
        candidate = discover_candidate(client, api_key, seen)
    if not candidate:
        logger.warning("No eligible Creative Commons video found for slot %s", slot)
        # Don't consume the slot; the next poll retries it.
        return False

    store = JobStore(root)
    job = store.create_job(
        candidate["title"], source="youtube", source_url=candidate["url"], owner_id=owner_id
    )
    job.auto_publish = True
    job.auto_publish_platform = targets[0]["platform"]
    job.auto_publish_account = targets[0]["account"]
    job.platform = "youtube_shorts"
    store.save_job(job)

    job_dir = store.job_dir(job.id)
    (job_dir / "autopilot.json").write_text(json.dumps({
        **candidate,
        "discovered_at": now.isoformat(),
        "source_license": "Creative Commons Attribution",
        "autopilot_max_clips": 1,
        "target_platform": "youtube_shorts",
        "destinations": targets,
    }, ensure_ascii=False, indent=2), encoding="utf-8")

    state["last_slot"] = slot
    state["seen_ids"] = (list(state.get("seen_ids", [])) + [candidate["id"]])[-5000:]
    _write_state(state_file, state)
    enqueue_job(job.id, str(root))
    logger.info("Queued autopilot source %s (%s) as job %s", candidate["title"], candidate["id"], job.id)
    return True


def main() -> None:
    logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"))
    logger.info("Edgetape autopilot scheduler started (poll=%ss)", POLL_SECONDS)
    while True:
        try:
            run_once()
        except Exception:
            logger.exception("Autopilot scheduler tick failed")
        time.sleep(POLL_SECONDS)


if __name__ == "__main__":
    main()
