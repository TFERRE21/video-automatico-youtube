from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
import time
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from .storage import JobStore
from .users import LinkedAccount

logger = logging.getLogger(__name__)


class AccountStatus(Enum):
    HEALTHY = "healthy"
    RATE_LIMITED = "rate_limited"
    QUOTA_EXCEEDED = "quota_exceeded"
    ERROR = "error"


@dataclass
class UploadTask:
    job_id: str
    clip_id: str
    platform: str
    account_name: str
    priority: int = 0
    retries: int = 0
    created_at: float = field(default_factory=time.time)
    next_retry_at: float = 0

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "UploadTask":
        return cls(**data)


@dataclass
class AccountQuota:
    account_name: str
    platform: str
    uploads_today: int = 0
    last_upload: float = 0
    status: AccountStatus = AccountStatus.HEALTHY
    quota_reset_at: float = 0
    next_retry_at: float = 0
    consecutive_429: int = 0
    consecutive_403: int = 0
    last_error: str = ""

    def to_dict(self) -> dict:
        d = asdict(self)
        d["status"] = self.status.value
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "AccountQuota":
        data = data.copy()
        data["status"] = AccountStatus(data["status"])
        return cls(**data)


class PublishQueueManager:
    """
    Cola persistente de publicaciones con:
    - Rate limiting adaptativo por cuenta
    - Rotación automática entre cuentas vinculadas
    - Backoff exponencial en 429
    - Pausa 24h en 403 (quota exceeded)
    - Fallback a Studio link si API falla
    """

    MAX_UPLOADS_PER_DAY = 6
    MIN_DELAY_BETWEEN_UPLOADS = 600
    MAX_RETRIES_429 = 5
    BASE_BACKOFF_429 = 300
    MAX_BACKOFF_429 = 86400
    QUOTA_RESET_HOUR = 0

    def __init__(self, store: JobStore) -> None:
        self.store = store
        self.MAX_UPLOADS_PER_DAY = int(
            os.environ.get("EDGETAPE_MAX_UPLOADS_PER_DAY", self.MAX_UPLOADS_PER_DAY)
        )
        self.MIN_DELAY_BETWEEN_UPLOADS = int(
            os.environ.get("EDGETAPE_MIN_UPLOAD_DELAY", self.MIN_DELAY_BETWEEN_UPLOADS)
        )
        self.queue_file = store.root / "publish_queue.json"
        self.quota_file = store.root / "account_quotas.json"
        self._queue: list[UploadTask] = []
        self._quotas: dict[str, AccountQuota] = {}
        self._processing = False
        self._lock_held = False
        self._lock_fh: Any = None
        self._load_state()

    def _load_state(self) -> None:
        self._queue = [UploadTask.from_dict(t) for t in (self._read_json(self.queue_file) or [])]
        self._quotas = {
            k: AccountQuota.from_dict(v)
            for k, v in (self._read_json(self.quota_file) or {}).items()
        }
        self._reset_daily_quotas()

    @staticmethod
    def _read_json(path: Path) -> Any:
        """Lee y parsea `path`; si está trozado (JSON inválido por una escritura
        muerta a mitad), cae al `.tmp` atómico que esa escritura dejó antes de
        reemplazar. Nunca revienta: la cola puede reconstruirse desde cero."""
        for candidate in (path, path.with_suffix(".json.tmp")):
            if not candidate.exists():
                continue
            try:
                return json.loads(candidate.read_text(encoding="utf-8"))
            except Exception:
                continue
        return None

    def _save_state(self) -> None:
        qtmp = self.queue_file.with_suffix(".json.tmp")
        qtmp.write_text(json.dumps([t.to_dict() for t in self._queue]), encoding="utf-8")
        qtmp.replace(self.queue_file)
        ktmp = self.quota_file.with_suffix(".json.tmp")
        ktmp.write_text(
            json.dumps({k: v.to_dict() for k, v in self._quotas.items()}), encoding="utf-8"
        )
        ktmp.replace(self.quota_file)

    @contextlib.contextmanager
    def _lock_file(self):
        """Exclusión entre procesos para el JSON persistente de la cola.

        Con Celery en prefork hay varios procesos mutando publish_queue.json a
        la vez; sin lock la escritura puede quedar trozada (JSON inválido) y
        perderse tareas. Reentrante dentro del mismo proceso: si la instancia ya
        tiene el lock (transacciones anidadas), se devuelve sin re-lockear, así
        no hay deadlock de flock sobre un segundo fd. En Windows (dev, pool
        solo/inproc) no existe fcntl: best effort."""
        if self._lock_held:
            yield
            return
        fh = self.queue_file.with_suffix(".json.lock").open("a+")
        try:
            import fcntl
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
            self._lock_held = True
            self._lock_fh = fh
        except (ImportError, OSError):
            logger.debug("lock de archivo no disponible; best effort")
        try:
            yield
        finally:
            if self._lock_held:
                try:
                    fcntl.flock(self._lock_fh.fileno(), fcntl.LOCK_UN)  # noqa: F821
                except (ImportError, OSError):
                    pass
                self._lock_held = False
                self._lock_fh = None
            fh.close()

    def _transaction(self, fn: Any) -> Any:
        """Recarga el estado persistido, aplica `fn` sobre la copia fresca y
        persiste de nuevo, todo bajo el lock. Evita pisar actualizaciones que
        otro proceso haya escrito entre tanto."""
        with self._lock_file():
            self._load_state()
            result = fn()
            self._save_state()
            return result

    def _get_quota_key(self, platform: str, account: str) -> str:
        return f"{platform}:{account}"

    def _next_midnight_utc(self) -> float:
        now = time.time()
        local = time.gmtime(now)
        midnight = time.mktime((
            local.tm_year, local.tm_mon, local.tm_mday + 1,
            self.QUOTA_RESET_HOUR, 0, 0, 0, 0, 0
        ))
        return midnight

    def _reset_daily_quotas(self) -> None:
        now = time.time()
        for quota in self._quotas.values():
            if quota.quota_reset_at and now >= quota.quota_reset_at:
                if quota.status == AccountStatus.QUOTA_EXCEEDED:
                    quota.status = AccountStatus.HEALTHY
                quota.uploads_today = 0
                quota.consecutive_403 = 0
                quota.quota_reset_at = self._next_midnight_utc()

    def can_upload(self, platform: str, account: str) -> tuple[bool, str]:
        def _compute() -> tuple[bool, str]:
            return self._can_upload_unlocked(platform, account)
        return self._transaction(_compute)

    def _can_upload_unlocked(self, platform: str, account: str) -> tuple[bool, str]:
        self._reset_daily_quotas()
        key = self._get_quota_key(platform, account)
        quota = self._quotas.get(key)
        now = time.time()

        if not quota:
            return True, "new_account"

        if quota.status == AccountStatus.QUOTA_EXCEEDED:
            if now >= quota.quota_reset_at:
                quota.status = AccountStatus.HEALTHY
                quota.uploads_today = 0
                quota.consecutive_403 = 0
                quota.quota_reset_at = self._next_midnight_utc()
                self._save_state()
                return True, "quota_reset"
            # Pausa por NUESTRO tope diario (last_error queda vacío), no por el
            # uploadLimitExceeded del canal de YouTube (que setea last_error).
            # Si el límite configurado se subió, re-evaluar en vez de esperar a
            # medianoche: los clips quedados en cola pueden publicarse hoy.
            if not quota.last_error and quota.uploads_today < self.MAX_UPLOADS_PER_DAY:
                quota.status = AccountStatus.HEALTHY
                quota.quota_reset_at = self._next_midnight_utc()
                self._save_state()
                return True, "daily_limit_raised"
            return False, f"quota_exceeded_until_{int(quota.quota_reset_at)}"

        if quota.status == AccountStatus.RATE_LIMITED:
            if now >= quota.next_retry_at:
                quota.status = AccountStatus.HEALTHY
                quota.consecutive_429 = 0
                self._save_state()
                return True, "backoff_complete"
            return False, f"rate_limited_until_{int(quota.next_retry_at)}"

        if quota.uploads_today >= self.MAX_UPLOADS_PER_DAY:
            quota.status = AccountStatus.QUOTA_EXCEEDED
            quota.quota_reset_at = self._next_midnight_utc()
            self._save_state()
            return False, "daily_limit_reached"

        if now - quota.last_upload < self.MIN_DELAY_BETWEEN_UPLOADS:
            return False, f"min_delay_not_met_{self.MIN_DELAY_BETWEEN_UPLOADS}s"

        return True, "ok"

    def get_best_account(self, platform: str, accounts: list[LinkedAccount]) -> Optional[LinkedAccount]:
        platform_key = self._platform_to_account_platform(platform)
        platform_accounts = [a for a in accounts if a.platform == platform_key]
        if not platform_accounts:
            return None

        candidates = []
        for acc in platform_accounts:
            can, _ = self.can_upload(platform, acc.name)
            if can:
                quota = self._quotas.get(self._get_quota_key(platform, acc.name))
                uploads = quota.uploads_today if quota else 0
                candidates.append((uploads, acc))

        if not candidates:
            return None

        candidates.sort(key=lambda x: x[0])
        return candidates[0][1]

    def _platform_to_account_platform(self, platform: str) -> str:
        mapping = {
            "youtube_shorts": "youtube",
            "youtube": "youtube",
            "tiktok": "tiktok",
            "facebook_reels": "facebook",
            "instagram_reels": "instagram",
            "otros": "otros",
        }
        return mapping.get(platform, "otros")

    def record_upload(
        self, platform: str, account: str, success: bool, error_code: int = 0,
        reason: str = "",
    ) -> None:
        def _apply() -> None:
            self._record_upload_state(platform, account, success, error_code, reason)
        self._transaction(_apply)

    def _record_upload_state(
        self, platform: str, account: str, success: bool, error_code: int = 0,
        reason: str = "",
    ) -> None:
        key = self._get_quota_key(platform, account)
        quota = self._quotas.get(key) or AccountQuota(account_name=account, platform=platform)
        now = time.time()

        if success:
            quota.uploads_today += 1
            quota.last_upload = now
            quota.status = AccountStatus.HEALTHY
            quota.consecutive_429 = 0
            quota.consecutive_403 = 0
            quota.last_error = ""
        elif error_code == 400 and reason == "uploadLimitExceeded":
            # Límite diario del CANAL de YouTube alcanzado: pausa 24 h.
            # Es una restricción de la plataforma, independiente de la cuota del
            # proyecto de API; solo se resuelve esperando al día siguiente.
            quota.status = AccountStatus.QUOTA_EXCEEDED
            quota.quota_reset_at = self._next_midnight_utc()
            quota.consecutive_403 = 1
            quota.last_error = "límite diario del canal (uploadLimitExceeded)"
            logger.warning(
                "cuenta %s alcanzó el límite diario del canal; pausada hasta %s",
                account, quota.quota_reset_at,
            )
        elif error_code == 429:
            quota.consecutive_429 += 1
            quota.status = AccountStatus.RATE_LIMITED
            backoff = min(
                self.BASE_BACKOFF_429 * (2 ** (quota.consecutive_429 - 1)),
                self.MAX_BACKOFF_429
            )
            quota.next_retry_at = now + backoff
            quota.last_error = "rate limited (429)"
        elif error_code == 403:
            quota.consecutive_403 += 1
            if quota.consecutive_403 >= 2:
                quota.status = AccountStatus.QUOTA_EXCEEDED
                quota.quota_reset_at = self._next_midnight_utc()
            quota.last_error = f"quota (403: {quota.consecutive_403}/2)"

        self._quotas[key] = quota

    def enqueue(self, task: UploadTask) -> None:
        def _apply() -> None:
            self._queue.append(task)
            self._queue.sort(key=lambda t: (t.priority, t.created_at))
        self._transaction(_apply)

    def enqueue_many(self, tasks: list[UploadTask]) -> None:
        def _apply() -> None:
            self._queue.extend(tasks)
            self._queue.sort(key=lambda t: (t.priority, t.created_at))
        self._transaction(_apply)

    def _retry_at_for(self, quota: Optional["AccountQuota"], reason: str, now: float) -> float:
        """Cuándo debe reintentarse un task según el estado de la cuenta.

        Fallback genérico de +300s si no hay cuota, pero si el bloqueo es por
        min_delay / backoff 429 / reset diario, despertar justo cuando toque.
        """
        retry = now + 300
        if quota is not None:
            if quota.status == AccountStatus.QUOTA_EXCEEDED:
                retry = quota.quota_reset_at
            elif quota.status == AccountStatus.RATE_LIMITED:
                retry = quota.next_retry_at or retry
            elif reason.startswith("min_delay"):
                retry = quota.last_upload + self.MIN_DELAY_BETWEEN_UPLOADS
        return retry

    def get_pending_for_job(self, job_id: str) -> list[UploadTask]:
        return [t for t in self._queue if t.job_id == job_id]

    async def process_queue(self, store: JobStore, publish_fn, get_accounts_fn) -> None:
        if self._processing:
            return
        self._processing = True

        try:
            while True:
                self._transaction(lambda: None)  # recargar cola y cuotas frescas
                if not self._queue:
                    break
                task = self._queue[0]
                now = time.time()

                if task.next_retry_at > now:
                    await asyncio.sleep(min(task.next_retry_at - now, 60))
                    continue

                can, reason = self.can_upload(task.platform, task.account_name)
                if not can:
                    accounts = get_accounts_fn()
                    best = self.get_best_account(task.platform, accounts)
                    if best and best.name != task.account_name:
                        def _swap(name: str = best.name) -> None:
                            if self._queue:
                                self._queue[0].account_name = name
                        self._transaction(_swap)
                        continue
                    # En vez de un retry genérico de +300s, despertar justo cuando
                    # la cuenta vuelva a permitir subir (fin del min_delay, del
                    # backoff de 429 o del reset diario).
                    def _schedule(reason_: str = reason, now_: float = now) -> None:
                        if not self._queue:
                            return
                        t = self._queue[0]
                        q = self._quotas.get(self._get_quota_key(t.platform, t.account_name))
                        t.next_retry_at = self._retry_at_for(q, reason_, now_)
                    self._transaction(_schedule)
                    retry = task.next_retry_at
                    wait = max(1, min(retry - now, 60))
                    await asyncio.sleep(wait)
                    continue

                task = self._transaction(
                    lambda: self._queue.pop(0) if self._queue else None
                )
                if task is None:
                    continue
                try:
                    job = store.get_job(task.job_id)
                    clip = next((c for c in store.get_clips(task.job_id) if c.id == task.clip_id), None)
                    if job and clip:
                        result = await publish_fn(store, job, clip, task.platform, task.account_name)
                        success = result is not None and result.status == "publicado"
                        error_code = 0
                        reason = ""
                        if not success and hasattr(result, "error"):
                            error_code = getattr(result.error, "status_code", 0) if hasattr(result.error, "status_code") else 0
                            reason = getattr(result.error, "reason", "")
                        self.record_upload(task.platform, task.account_name, success, error_code, reason)
                except Exception as e:
                    error_code = getattr(e, "response", {}).get("status_code", 0) if hasattr(e, "response") else 0
                    if hasattr(e, "status_code"):
                        error_code = e.status_code
                    reason = getattr(e, "reason", "")
                    self.record_upload(task.platform, task.account_name, False, error_code, reason)
                    task.retries += 1
                    if task.retries <= self.MAX_RETRIES_429:
                        task.next_retry_at = time.time() + (60 * task.retries)
                        def _reinsert(t: UploadTask = task) -> None:
                            self._queue.insert(0, t)
                        self._transaction(_reinsert)

                delay = float(os.environ.get("EDGETAPE_QUEUE_TASK_DELAY", 10))
                if delay > 0:
                    await asyncio.sleep(delay)

        finally:
            self._processing = False

    def get_status_summary(self) -> dict:
        self._reset_daily_quotas()
        return {
            "pending_tasks": len(self._queue),
            "account_quotas": {
                k: {
                    "uploads_today": v.uploads_today,
                    "status": v.status.value,
                    "next_retry": v.next_retry_at if v.status == AccountStatus.RATE_LIMITED else None,
                    "quota_reset": v.quota_reset_at if v.status == AccountStatus.QUOTA_EXCEEDED else None,
                }
                for k, v in self._quotas.items()
            }
        }


_queue_managers_by_root: dict[str, PublishQueueManager] = {}


def get_queue_manager(store: JobStore) -> PublishQueueManager:
    """Devuelve el manager cacheado por raíz de storage.

    En producción hay una sola raíz (un solo manager compartido); en tests, cada
    tmp_path obtiene su propio manager y no hay contaminación cruzada entre
    tests que usen raíces distintas."""
    root = str(store.root)
    manager = _queue_managers_by_root.get(root)
    if manager is None:
        manager = PublishQueueManager(store)
        _queue_managers_by_root[root] = manager
    return manager